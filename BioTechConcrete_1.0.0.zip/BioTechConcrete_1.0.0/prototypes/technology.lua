data:extend(
{
  {
	type = "technology",
    name = "Bio-Tech Concrete",
    icon = "__BioTechConcrete__/graphics/icons/biotech_concrete-icon.png",
    icon_size = 64,
	prerequisites = {"concrete"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
		{"chemical-science-pack", 1},
      },
      time = 10
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "biotech_concrete"
      },
	  {
        type = "unlock-recipe",
        recipe = "biotech_concrete_blueprint"
      },
	  {
	    type = "unlock-recipe",
        recipe = "biotech_concrete_blueprint-to-normal"
	  }
	  
	  
	},
	
      
	  order = "c-c-d"	
    } 
}
)	

	  
	  