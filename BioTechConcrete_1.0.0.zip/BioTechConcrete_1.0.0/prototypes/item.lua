data:extend(
{
	{
    
	type = "item",
	name = "biotech_concrete",
	icon = "__BioTechConcrete__/graphics/icons/biotech_concrete-icon.png",
	icon_size = 64,
	flags = {},
	subgroup = "terrain",
	order = "d",
	stack_size = 1000,
	place_as_tile =
	 {
	  result = "biotech_concrete",
	  condition_size = 1,
	  condition = { "water-tile" }
	 }	
	 },	
	  
	 {
    
	type = "item",
	name = "biotech_concrete_blueprint",
	icon = "__BioTechConcrete__/graphics/icons/biotech_concrete_blueprint-icon.png",
	icon_size = 64,
	flags = {},
	subgroup = "terrain",
	order = "d",
	stack_size = 1000,
	place_as_tile =
	 {
	  result = "biotech_concrete_blueprint",
	  condition_size = 1,
	  condition = { "water-tile" }
	 }	
	 }
	
}
)