local grasstilespeed = 2.0
local delpollutegrass = 20.0

data:extend(
{
  {	  
  
  
	  type = "tile",
      name = "biotech_concrete",
      needs_correction = false,
      minable = {hardness = 0.2, mining_time = 0.3, result = "biotech_concrete"},
      mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
      collision_mask = {"ground-tile"},
      walking_speed_modifier = 2.0,
	  can_be_part_of_blueprint = false,
      layer = 60,
      decorative_removal_probability = 0.9,
      variants =
      {
        main =
      {
        {
          picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
          count = 1,
          size = 1
        },
        {
          picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
          count = 1,
          size = 2,
          probability = 0.39
        },
        {
          picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
          count = 1,
          size = 4,
          probability = 1
        }
      },
	  material_background =
      {
        picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete.png",
        count = 1,
		scale = 0.5
      },
		
        inner_corner =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-inner-corner.png",
          count = 16,
	      scale = 0.5 
        },
		inner_corner_mask =
		{
		  picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-inner-corner-mask.png",
          count = 16,
	      scale = 0.5 
		},
		
        outer_corner =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-outer-corner.png",
          count = 8,
		  scale = 0.5
        },
        outer_corner_mask =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-outer-corner-mask.png",
          count = 8,
		  scale = 0.5
        },
		
        side =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-side.png",
          count = 16,
		  scale=0.5
        },
		side_mask = 
		{
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-side-mask.png",
          count = 16,
		  scale=0.5
        },
		
		o_transition =
		{
          picture = "__BioTechConcrete__/graphics/terrain/biotech_concrete-o.png",
          count = 4,
		  scale = 0.5
        },
		
		o_transition_mask =
		{
          picture = "__BioTechConcrete__/graphics/terrain/biotech_concrete-o-mask.png",
          count = 4,
		  scale = 0.5
        },
		
		u_transition =
         {
        picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-u.png",
        count = 8,
		scale = 0.5
        },
		
        u_transition_mask =
		 {
        picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-u-mask.png",
        count = 8,
		scale = 0.5
         },


       
      },
	  
	  
      walking_sound =
      {
        {
          filename = "__base__/sound/walking/grass-01.ogg",
          volume = 1.2
        },
        {
          filename = "__base__/sound/walking/grass-02.ogg",
          volume = 1.2
        },
        {
          filename = "__base__/sound/walking/grass-03.ogg",
          volume = 1.2
        },
        {
          filename = "__base__/sound/walking/grass-04.ogg",
          volume = 1.2
        }
      },
      map_color={r=57, g=48, b=16},
      ageing=0,
      vehicle_friction_modifier = concrete_vehicle_speed_modifier,
	  pollution_absorption_per_second = delpollutegrass
  },

  {	  
  
  
	  type = "tile",
      name = "biotech_concrete_blueprint",
      needs_correction = false,
      minable = {hardness = 0.2, mining_time = 0.5, result = "biotech_concrete_blueprint"},
      mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
      collision_mask = {"ground-tile"},
      walking_speed_modifier = grasstilespeed,
	  can_be_part_of_blueprint = true,
      layer = 61,
      decorative_removal_probability = 0.9,
      variants =
      {
        main =
      {
        {
          picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
          count = 1,
          size = 1
        },
        {
          picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
          count = 1,
          size = 2,
          probability = 0.39
        },
        {
          picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
          count = 1,
          size = 4,
          probability = 1
        }
      },
	  material_background =
      {
        picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete.png",
        count = 1,
		scale = 0.5
      },
		
        inner_corner =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-inner-corner.png",
          count = 16,
	      scale = 0.5 
        },
		inner_corner_mask =
		{
		  picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-inner-corner-mask.png",
          count = 16,
	      scale = 0.5 
		},
		
        outer_corner =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-outer-corner.png",
          count = 8,
		  scale = 0.5
        },
        outer_corner_mask =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-outer-corner-mask.png",
          count = 8,
		  scale = 0.5
        },
		
        side =
        {
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-side.png",
          count = 16,
		  scale=0.5
        },
		side_mask = 
		{
          picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-side-mask.png",
          count = 16,
		  scale=0.5
        },
		
		o_transition =
		{
          picture = "__BioTechConcrete__/graphics/terrain/biotech_concrete-o.png",
          count = 4,
		  scale = 0.5
        },
		
		o_transition_mask =
		{
          picture = "__BioTechConcrete__/graphics/terrain/biotech_concrete-o-mask.png",
          count = 4,
		  scale = 0.5
        },
		
		u_transition =
         {
        picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-u.png",
        count = 8,
		scale = 0.5
        },
		
        u_transition_mask =
		 {
        picture = "__BioTechConcrete__/graphics/terrain/biotech-concrete-u-mask.png",
        count = 8,
		scale = 0.5
         },


       
      },
	  
	  
      walking_sound =
      {
        {
          filename = "__base__/sound/walking/grass-01.ogg",
          volume = 1.2
        },
        {
          filename = "__base__/sound/walking/grass-02.ogg",
          volume = 1.2
        },
        {
          filename = "__base__/sound/walking/grass-03.ogg",
          volume = 1.2
        },
        {
          filename = "__base__/sound/walking/grass-04.ogg",
          volume = 1.2
        }
      },
      map_color={r=57, g=48, b=16},
      ageing=0,
      vehicle_friction_modifier = concrete_vehicle_speed_modifier,
	  pollution_absorption_per_second = delpollutegrass
  }
  
	 
}
)	 
		 
	