data:extend(
{
  
   {

    
	type = "recipe",
     name = "biotech_concrete",
    energy_required = 10,
    enabled = false,
    category = "crafting-with-fluid",
    ingredients =
    {
      {"iron-stick", 4},
	  {"waterfill", 4},
	  {type="fluid", name="water", amount=20}
    },
    result= "biotech_concrete",
    result_count = 10
   },
   
   {
	type = "recipe",
     name = "biotech_concrete_blueprint",
    energy_required = 0.25,
    enabled = false,
    category = "crafting",
    ingredients =
    {
      {"biotech_concrete", 10} 
    },
    result= "biotech_concrete_blueprint",
    result_count = 10
   },
   {
	type = "recipe",
     name = "biotech_concrete_blueprint-to-normal",
    energy_required = 0.25,
    enabled = false,
    category = "crafting",
    ingredients =
    {
      {"biotech_concrete_blueprint", 10} 
    },
    result= "biotech_concrete",
    result_count = 10
   },
   
   
}
)

  