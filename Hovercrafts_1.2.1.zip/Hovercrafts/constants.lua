HCGRAPHICS = "__Hovercrafts__/graphics/"
car_sounds = {
  sound = { filename = "__base__/sound/car-engine.ogg", volume = 0.6 },
  activate_sound = { filename = "__base__/sound/car-engine-start.ogg", volume = 0.6 },
  deactivate_sound = { filename = "__base__/sound/car-engine-stop.ogg", volume = 0.6 },
  match_speed_to_activity = true
}