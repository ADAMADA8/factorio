-- armors & bonuses
-- light-armor
-- heavy-armor
-- modular-armor    -- inventory_size_bonus = 10
-- power-armor      -- inventory_size_bonus = 20
-- power-armor-mk2  -- inventory_size_bonus = 30

-- default entity protected stats
-- inventory_size = 80,
-- build_distance = 10,
-- drop_item_distance = 10,
-- reach_distance = 10,
-- item_pickup_distance = 1,
-- loot_pickup_distance = 2,
-- enter_vehicle_distance = 3,
-- reach_resource_distance = 2.7,

-- force/player entity public stats
-- character_build_distance_bonus :: uint [RW]	
-- character_item_drop_distance_bonus :: uint [RW]	
-- character_reach_distance_bonus :: uint [RW]	
-- character_resource_reach_distance_bonus :: double [RW]	
-- character_item_pickup_distance_bonus :: double [RW]	
-- character_loot_pickup_distance_bonus :: double [RW]

function check_armor_change_player_reach(player)

  -- check inventory exists, otherwise it would crash in sandbox mode (characterless)
  local inventory_armor = player.get_inventory(defines.inventory.character_armor)
  -- debug
  -- local player = game.players[1]
  -- player.print("VTK-ARMOR-REACH_DEBUG")
  -- player.print(serpent.block(player))
  -- player.print(serpent.block(inventory_armor))
  -- player.print(serpent.block(player.character_crafting_speed_modifier))
  -- player.print(serpent.block(player.character_health_bonus))
  
  if inventory_armor == nil then
    return
  end

  if player.character == nil then
    return
  end

  local inventory_content = inventory_armor.get_contents()
  
  if inventory_content["light-armor"] ~= nil
   or inventory_content["tiny-armor-mk1"] ~= nil
   or inventory_content["pamk3-lvest"] ~= nil
   or inventory_content["early-construction-light-armor"] ~= nil
  then
    player.character_build_distance_bonus = 3
    player.character_item_drop_distance_bonus = 3
    player.character_reach_distance_bonus = 3
    player.character_resource_reach_distance_bonus = 1.3
    player.character_crafting_speed_modifier = 0.10
    player.character_mining_speed_modifier = 0.10
    player.character_health_bonus = 10
  elseif inventory_content["heavy-armor"] ~= nil
   or inventory_content["tiny-armor-mk2"] ~= nil
   or inventory_content["heavy-armor-2"] ~= nil
   or inventory_content["heavy-armor-3"] ~= nil
   or inventory_content["pamk3-hvest"] ~= nil
   or inventory_content["early-construction-heavy-armor"] ~= nil
   or inventory_content["Schall-engineering-suit-basic"] ~= nil
  then
    player.character_build_distance_bonus = 6
    player.character_item_drop_distance_bonus = 6
    player.character_reach_distance_bonus = 6
    player.character_resource_reach_distance_bonus = 2.7
    player.character_crafting_speed_modifier = 0.20
    player.character_mining_speed_modifier = 0.20
    player.character_health_bonus = 25
  elseif inventory_content["modular-armor"] ~= nil
    or inventory_content["Schall-engineering-suit"] ~= nil
  then
    player.character_build_distance_bonus = 9
    player.character_item_drop_distance_bonus = 9
    player.character_reach_distance_bonus = 9
    player.character_resource_reach_distance_bonus = 5.4
    player.character_crafting_speed_modifier = 0.40
    player.character_mining_speed_modifier = 0.40
    player.character_health_bonus = 50
  elseif inventory_content["power-armor"] ~= nil
    or inventory_content["se-thruster-suit"] ~= nil
    or inventory_content["Schall-engineering-suit-mk1"] ~= nil
  then
    player.character_build_distance_bonus = 12
    player.character_item_drop_distance_bonus = 12
    player.character_reach_distance_bonus = 12
    player.character_resource_reach_distance_bonus = 8.1
    player.character_crafting_speed_modifier = 0.80
    player.character_mining_speed_modifier = 0.80
    player.character_health_bonus = 100
  elseif inventory_content["power-armor-mk2"] ~= nil
    or inventory_content["se-thruster-suit-2"] ~= nil
    or inventory_content["Schall-engineering-suit-mk2"] ~= nil
  then
    player.character_build_distance_bonus = 15
    player.character_item_drop_distance_bonus = 15
    player.character_reach_distance_bonus = 15
    player.character_resource_reach_distance_bonus = 10.8
    player.character_crafting_speed_modifier = 1.6
    player.character_mining_speed_modifier = 1.6
    player.character_health_bonus = 150
  elseif inventory_content["power-armor-mk3"] ~= nil
   or inventory_content["bob-power-armor-mk3"] ~= nil
   or inventory_content["se-thruster-suit-3"] ~= nil
   or inventory_content["pamk3-pamk3"] ~= nil
   or inventory_content["simply-power-armor-mk3"] ~= nil
   or inventory_content["Schall-engineering-suit-mk3"] ~= nil
  then
    player.character_build_distance_bonus = 18
    player.character_item_drop_distance_bonus = 18
    player.character_reach_distance_bonus = 18
    player.character_resource_reach_distance_bonus = 15.6
    player.character_crafting_speed_modifier = 3.2
    player.character_mining_speed_modifier = 3.2
    player.character_health_bonus = 200
  elseif inventory_content["power-armor-mk4"] ~= nil
   or inventory_content["bob-power-armor-mk4"] ~= nil
   or inventory_content["se-thruster-suit-4"] ~= nil
   or inventory_content["pamk3-pamk4"] ~= nil
  then
    player.character_build_distance_bonus = 21
    player.character_item_drop_distance_bonus = 21
    player.character_reach_distance_bonus = 21
    player.character_resource_reach_distance_bonus = 20.2
    player.character_crafting_speed_modifier = 6.4
    player.character_mining_speed_modifier = 6.4
    player.character_health_bonus = 250
  elseif inventory_content["bob-power-armor-mk5"] ~= nil
  then
    player.character_build_distance_bonus = 25
    player.character_item_drop_distance_bonus = 25
    player.character_reach_distance_bonus = 25
    player.character_resource_reach_distance_bonus = 25
    player.character_crafting_speed_modifier = 12.8
    player.character_mining_speed_modifier = 12.8
    player.character_health_bonus = 300
  else -- no known armor, default range
    player.character_build_distance_bonus = 0
    player.character_item_drop_distance_bonus = 0
    player.character_reach_distance_bonus = 0
    player.character_resource_reach_distance_bonus = 0
    player.character_crafting_speed_modifier = 0
    player.character_mining_speed_modifier = 0
    player.character_health_bonus = 0
  end
end

-- events hook, on load
script.on_configuration_changed(
  function(event)
    for index,player in pairs(game.players) do
      check_armor_change_player_reach(player)
    end
end)

-- events hook, on equip armor
script.on_event(defines.events.on_player_armor_inventory_changed,
  function(event)
    -- player_index :: uint
    local player_index = event.player_index
    if(player_index ~= nil) then
      local player = game.players[player_index]
      check_armor_change_player_reach(player)
    end
end)

-- events hook, on respawn
script.on_event(defines.events.on_player_respawned,
  function(event)
    -- player_index :: uint
    local player_index = event.player_index
    if(player_index ~= nil) then
      local player = game.players[player_index]
      check_armor_change_player_reach(player)
    end
end)

-- events hook, on player join
script.on_event(defines.events.on_player_joined_game,
  function(event)
    -- player_index :: uint
    local player_index = event.player_index
    if(player_index ~= nil) then
      local player = game.players[player_index]
      check_armor_change_player_reach(player)
    end
end)
