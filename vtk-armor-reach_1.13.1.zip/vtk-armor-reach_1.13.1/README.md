[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/T6T427A37)

# VortiK's Armor Reach

Small mod that increase the player character reach range depending on the equiped armor.

Inspired from Long Reach Research https://mods.factorio.com/mods/Mooncat/long-reach-research
And discussion on Reddit : https://www.reddit.com/r/factorio/comments/6fdehh/i_feel_like_higher_tier_power_armor_should_also/

## Features
It increases reach for : 
- Interacting with inventories (eg.: chests) and changing assembler blueprints
- Building
- Droping items on the ground
- Mining, trees, ore, rocks

Reach is updated for player on armor equip, game join, game load and respawn !

Since version 1.13 also increase the player handcrafting, mining speed and health : 
- Light 10% + 10 hp
- Heavy 20% + 25 hp
- Modular 40% + 50 hp
- Power 80% + 100 hp
- Power mk2 160% + 150 hp
- Power mk3 320% + 200 hp
- Power mk4 640% + 250 hp
- Power mk5 1280% & + 300 hp

## Compatibility

Will work for vanilla armors : 
- `light-armor`
- `heavy-armor`
- `modular-armor`
- `power-armor`
- `power-armor-mk2`.

Will work for the following modded armors : 

Power Armor MK3 & MK4 https://mods.factorio.com/mod/Power%20Armor%20MK3 : 
- `pamk3-pamk3`
- `pamk3-pamk4`
- `pamk3-lvest`
- `pamk3-hvest`

Tiny Start Micro Armors https://mods.factorio.com/mod/TinyStart : 
- `tiny-armor-mk1`
- `tiny-armor-mk2`

Bob's Warfare https://mods.factorio.com/mod/bobwarfare : 
- `heavy-armor-2`
- `heavy-armor-3`
- `bob-power-armor-mk3`
- `bob-power-armor-mk4`
- `bob-power-armor-mk5`

Space Exploration Thruster Suits 1 to 4 https://mods.factorio.com/mod/space-exploration : 
- `se-thruster-suit`

Early Construction Light and Heavy armors https://mods.factorio.com/mod/early_construction : 
- `early-construction-light-armor`
- `early-construction-heavy-armor`

Krastorio 2's Power Armor MK3 & MK4 https://mods.factorio.com/mod/Krastorio2 : 
- `power-armor-mk3`
- `power-armor-mk4`

Simply Power Armor MK3 https://mods.factorio.com/mod/simply-power-armor-mk3 :
- `simply-power-armor-mk3`

Shall Suit https://mods.factorio.com/mod/SchallSuit :
- `Schall-engineering-suit-basic`
- `Schall-engineering-suit`
- `Schall-engineering-suit-mk1`
- `Schall-engineering-suit-mk2`
- `Schall-engineering-suit-mk3`