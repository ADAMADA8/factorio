data:extend({
  {
    type = 'technology',
    name = 'seed-extraction',
    icon = '__SimpleSaplings__/graphics/technology/seed-extraction.png',
    icon_size = 128,
    effects = {
      {
        type = 'unlock-recipe',
        recipe = 'sapling'
      }
    },
    prerequisites = {},
    unit = {
      count = 10,
      ingredients = {
        { 'automation-science-pack', 1 },
        { 'logistic-science-pack', 1 }
      },
      time = 30
    }
  }
})
