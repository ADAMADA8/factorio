Simple Saplings
---------------

A "fork" of [JJdJJ's Tree Planting Mod](https://mods.factorio.com/mods/JJtJJ/TreeSeeds).

## Summary
Simple Saplings adds one item and one researchable crafting recipe, a sapling and seed extraction, respectively.

Saplings are dropped from manually chopped trees and extracted from raw wood. Once planted, they'll grow after a few in-game days.

## Authors
- will-janz
- Nexela
- BoBkiNN_

## License
MIT
