# Unlimited Resources (Oil Refresh)

Ore deposits get refreshed when emptied. Oil will be refreshed based on a timer. Both can be disabled. This is based on the 'Unlimited Resources' mod from Barry.
