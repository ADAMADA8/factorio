data:extend({
  {
    type = "item",
    name = "beaconmk2",
    icon = "__BeaconMk2__/graphics/icons/beacon1.png",
    subgroup = "module",
    order = "a[beacon]",
	icon_size = 32,
    place_result = "beaconmk2",
    stack_size = 10
  }
})