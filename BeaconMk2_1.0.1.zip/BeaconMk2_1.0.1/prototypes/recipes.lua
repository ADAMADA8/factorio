data:extend({
  {
    type = "recipe",
    name = "beaconmk2",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {"beacon", 2},
      {"processing-unit", 10}
    },
    result = "beaconmk2"
  }
})