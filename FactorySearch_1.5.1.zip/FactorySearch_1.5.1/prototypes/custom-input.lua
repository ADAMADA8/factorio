local open_search_prototype = {
	type = "custom-input",
	name = "open-search-prototype",
	key_sequence = "CONTROL + SHIFT + mouse-button-1",
  consuming = "none",
  include_selected_prototype = true,
  order = "a"
}

data:extend{open_search_prototype}