-- Taken from flib
local fab = "__FactorySearch__/graphics/frame-action-icons.png"

data:extend{
  { type = "sprite", name = "fs_flib_pin_black", filename = fab, position = { 0, 0 }, size = 32, flags = { "icon" } },
  { type = "sprite", name = "fs_flib_pin_white", filename = fab, position = { 32, 0 }, size = 32, flags = { "icon" } }
}