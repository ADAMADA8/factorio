require "prototypes.shortcuts"
require "prototypes.custom-input"
require "prototypes.sprite"
require "prototypes.style"