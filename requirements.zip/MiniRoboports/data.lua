require("prototypes.roboport-mini")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technologies")
