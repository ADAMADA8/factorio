data:extend
(
  {
    {
      type = "recipe",
      name = "roboport-mini",
      enabled = false,
      energy_required = 5,
      ingredients =
      {
        {"steel-plate", 35},
        {"iron-gear-wheel", 35},
        {"advanced-circuit", 35}
      },
      result = "roboport-mini"
    },
  }
)
