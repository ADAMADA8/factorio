![GitHub release (latest by date)](https://img.shields.io/github/v/release/Porkchop13/Factorio-Modules-T4?label=Release) 

# Factorio Tier 4 Modules
Factorio mod adding Tier 4 modules with configurable bonuses
 
[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/Q5Q3BKJE8)
