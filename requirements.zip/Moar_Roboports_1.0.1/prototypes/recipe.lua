data:extend(
  {
    {
      type = "recipe",
      name = "roboport-ext",
      enabled = false,
      energy_required = 10,
      ingredients =
      {
        {"steel-plate", 10},
        {"radar",2},
        {"roboport", 10},
        {"processing-unit", 20}
      },
      result = "roboport-ext"
    },
    {
      type = "recipe",
      name = "roboport-prod",
      enabled = false,
      energy_required = 20,
      ingredients =
      {
        {"steel-plate", 25},
        {"radar",2},
        {"roboport", 10},
        {"processing-unit", 20}
      },
      result = "roboport-prod"
		},
    {
      type = "recipe",
      name = "roboport-prod2",
      enabled = false,
      energy_required = 20,
      ingredients =
      {
        {"steel-plate", 25},
        {"radar",2},
        {"roboport", 10},
        {"processing-unit", 20}
      },
      result = "roboport-prod2"
		},
		
		
  }
)