data:extend({
  {
    type = "item",
    name = "roboport-ext",
    icon = "__Moar_Roboports__/graphics/icons/roboport-ext.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "logistic-network",
    order = "c[signal]-a[roboport]",
    place_result = "roboport-ext",
    stack_size = 10,
  },
  {
    type = "item",
    name = "roboport-prod",
    icon = "__Moar_Roboports__/graphics/icons/roboport-prod.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "logistic-network",
    order = "c[signal]-a[roboport]",
    place_result = "roboport-prod",
    stack_size = 10,
  },
  {
    type = "item",
    name = "roboport-prod2",
    icon = "__Moar_Roboports__/graphics/icons/roboport-prod2.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "logistic-network",
    order = "c[signal]-a[roboport]",
    place_result = "roboport-prod2",
    stack_size = 10,
  }
  
})