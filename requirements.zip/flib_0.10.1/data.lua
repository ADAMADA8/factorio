require("prototypes/sprite")
require("prototypes/style")
