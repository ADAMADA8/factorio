for k, v in pairs(data.raw.module) do
	log("Detected module: " .. v.name)
	if v.limitation then
		log("Removing limitations!")
		v.limitation = nil
	end
end
