local handler = require("event_handler")

handler.add_lib(require("script/train_control_signals"))