data:extend({
    {
        name = "afk-pause-timeout",
        type = "bool-setting",
        setting_type = "runtime-global",
        default_value = true
    },
    {
        name = "afk-pause-nth-tick",
        type = "int-setting",
        setting_type = "runtime-global",
        default_value = 603,
        hidden = true
    },
    {
        name = "afk-pause-timeout-seconds",
        type = "int-setting",
        setting_type = "runtime-global",
        default_value = 900
    }
})