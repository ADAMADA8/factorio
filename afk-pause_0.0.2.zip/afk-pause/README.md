# Factorio AFK Pause
This factorio mod helps players pause a multiplayer game. It is meant for setups with a few people who go afk somewhat regularly but who would like the game to be paused if nobody is around.

# Modes
There are two non exclusive modes:
- manually declare afk state using a button.
- auto declare afk state with a timeout

## Button
Each player has a button in a frame. The button and frame show the pause state and afk state of the player. The button can toggle the afk state of the player. If all connected players are in afk state the game ticks will pause.

## Timeout
After a configurable number of seconds (ticks) a user will be flagged as afk. They dont need to manually click afk.

Having the timeout feature active causes the mod to register an nth tick handler. The handler checks players' afk_time as given by the game engine. If the time is greater than the configured threshold the game will go afk.

## UnAfk
To change your state from afk to not afk so that the game resumes click on the main button of the mod.
