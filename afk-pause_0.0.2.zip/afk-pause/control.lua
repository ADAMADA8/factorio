local ui_frame_name = "afk-pause"
local button_name = "afk-pause"

local frame_pause_caption = "afk-paused"
local frame_not_pause_caption = "afk-unpaused"

local afk_button_caption = "afk"
local not_afk_button_caption = "!afk"

local function get_frame(player)
    local frame = player.gui.top[ui_frame_name]
    if not frame or not frame.valid then
        return nil
    end
    return frame
end

local function get_button(player)
    local frame = get_frame(player)
    if frame and frame[button_name] then
        return frame[button_name]
    end
    return nil
end

local function ensure_ui()
    for _, player in pairs(game.players) do
        local frame = get_frame(player)
        if not frame then
            if player.gui.screen[ui_frame_name] then
                player.gui.screen[ui_frame_name].destroy()
            end

            frame = player.gui.top.add {
                type = "frame",
                name = ui_frame_name,
                caption = "afk-pause"
            }
            local button = frame.add {
                type = "button",
                name = button_name,
                caption = not_afk_button_caption
            }
        end
    end
end

local function update_ui()
    local caption = frame_not_pause_caption
    if game.tick_paused then
        caption = frame_pause_caption
    end

    for _, player in pairs(game.players) do
        local frame = get_frame(player)
        if frame then
            frame.caption = caption
        end
    end
end

local function pause()
    game.tick_paused = true
    update_ui()
end

local function unpause()
    game.tick_paused = false
    update_ui()
end

local function check_pause()
    local should_pause = true
    for _, player in pairs(game.players) do
        if player.connected then
            local button = get_button(player)
            if button then
                if button.caption == not_afk_button_caption then
                    should_pause = false
                end
            end
        end
    end

    if should_pause and not game.tick_paused then
        pause()
    elseif not should_pause and game.tick_paused then
        unpause()
    end
end

local function player_left(player)
    check_pause()
end

local function player_joined(player)
    ensure_ui()
    check_pause()
end

local function check_afk()
    local found_afk = false

    local afk_timeout = settings.global["afk-pause-timeout-seconds"].value * 60

    if afk_timeout < 1 then
        return
    end

    for _, player in pairs(game.players) do
        if player.connected then
            if player.afk_time > afk_timeout then
                local button = get_button(player)
                if button then
                    if button.caption ~= afk_button_caption then
                        button.caption = afk_button_caption
                        found_afk = true
                    end
                end
            end
        end
    end

    if found_afk then
        check_pause()
    end
end

script.on_event(defines.events.on_player_joined_game, function (event)
    player_joined(game.players[event.player_index])
end)

script.on_event(defines.events.on_player_left_game, function (event)
    player_left(game.players[event.player_index])
end)

script.on_event(defines.events.on_gui_click, function(event)
    local button = event.element
    if button.name == button_name then
        if button.caption ~= not_afk_button_caption then
            button.caption = not_afk_button_caption
        else
            button.caption = afk_button_caption
        end
        check_pause()
    end
end)

if settings.global["afk-pause-timeout"].value then
    script.on_nth_tick(settings.global["afk-pause-nth-tick"].value, function ()
        check_afk()
    end)
end

commands.add_command("afk_unpause", "", function ()
    unpause()
end)

commands.add_command("afk_pause", "", function ()
    pause()
end)

commands.add_command("afk_pause_ensure_ui", "", function ()
    ensure_ui()
end)

commands.add_command("afk_pause_check", "", function ()
    check_pause()
end)
