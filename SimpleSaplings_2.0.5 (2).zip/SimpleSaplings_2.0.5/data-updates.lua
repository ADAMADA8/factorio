for name, tree in pairs (data.raw['tree']) do
    if not(string.find(name, 'dead') or string.find(name, 'dry') or string.find(name, 'coral') or string.find(name, 'stick') or name == 'sapling') then
        if tree.minable then
            
            -- If a tree only has one resource, and it's wood, convert it to use results.
            -- Should prevent breaking trees made by other mods.
            if tree.minable.result ~= nil and tree.minable.result == 'wood' then
                tree.minable.result = nil
                tree.minable.results = {}

                table.insert(tree.minable.results, {
                    type = 'item',
                    name = 'wood',
                    amount_min = 4,
                    amount_max = 4,
                    probability = 1
                })

                -- Add sapling.
                table.insert(tree.minable.results, {
                    type = 'item',
                    name = 'sapling',
                    amount_min = 1,
                    amount_max = 2,
                    probability = 1
                })
            end
        end
    end
end
