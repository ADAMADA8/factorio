# Simple Saplings

A "fork" of [JJdJJ's Tree Planting Mod](https://mods.factorio.com/mods/JJtJJ/TreeSeeds).

## Summary

Simple Saplings adds one item and one researchable crafting recipe, a sapling and seed extraction, respectively.

Saplings are dropped from chopped trees and extracted from raw wood. Once planted, they'll grow after a few in-game days.

A big thanks to Nexela for their help with optimizing, and SpaceReptile for the new art!

**NOW BLUEPRINTABLE**
On update, any ungrown but planted saplings from previous versions will be removed.

### Pitch

Do you want a marginally effective method to reduce pollution? Do you want to plant so many trees Captain Planet blushes redder than his tights? Do you like making forest fires?

Simple Saplings lets you regrow as much forest as you wish, for whatever reason.

## TODO

Add settings for the amount of saplings trees give.
