data:extend({
  {
    type = 'recipe',
    name = 'sapling',
    icon_size = 32,
    enabled = false,
    ingredients = {
      { 'wood', 1 }
    },
    result = 'sapling'
  }
})
