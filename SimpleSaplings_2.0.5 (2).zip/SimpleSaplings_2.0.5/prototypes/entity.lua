
data:extend({
  {
    type = 'simple-entity-with-owner',
    name = 'plant-stick',
    icon = '__SimpleSaplings__/graphics/icons/plant-stick.png',
    icon_size = 32, -- Shrinks

    flags = { 'placeable-neutral', 'breaths-air', 'not-repairable', 'player-creation' },

    minable = { hardness = 0.1, mining_time = 0.5, result = 'sapling' },
    placable_by = { { item = 'sapling', count = 1 }, { item = 'wood', count = 2 } },
    max_health = 20,
    corpse = 'small-remnants',
    collision_box = { { -0.15, -0.15 }, { 0.15, 0.15 } },
    selection_box = { { -0.4, -0.4 }, { 0.4, 0.4 } },
    selectable_in_game = true,
    drawing_box = { { -0.5, -0.5 }, { 0.5, 0.5 } },
    vehicle_impact_sound = { filename = '__base__/sound/car-wood-impact.ogg', volume = 0.5 },
    picture = {
      filename = '__SimpleSaplings__/graphics/entity/plant-stick.png',
      priority = 'extra-high',
      width = 125,
      height = 125,
      shift = { 0.6, -1.4 }
    },
    allow_copy_paste = true
  }
})
