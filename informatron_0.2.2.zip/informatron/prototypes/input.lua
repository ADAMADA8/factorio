data:extend{
    {
        type = 'custom-input',
        name = 'informatron',
        key_sequence = 'I',
        enabled_while_spectating = true,
    },
}
