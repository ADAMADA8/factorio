data:extend({
    {
        name='easy_dirty_water',
        type='recipe',
        enabled='true',
        category='el_purifier_category',
        main_product='el_dirty_water',
        ingredients={
            {type='fluid', name='water', amount=100},
            {type="item", name="stone", amount=4},
        },
        results={
            {type='fluid', name='el_dirty_water', amount=100},
        },
        energy_required=4,
        always_show_made_in = true
    }
})

-- name = 'fi_flourite_recipe',
-- type = 'recipe',
-- enabled = 'false',
-- category = 'crafting-with-fluid',
-- main_product = 'fi_materials_flourite',
-- ingredients = {
--     {type="fluid", name="el_dirty_water", amount=100},
-- },
-- results = {
--     {type="fluid", name="water", amount=100},
--     {type="item", name="fi_materials_flourite", amount=1},
-- },
-- energy_required = 0.2,
-- order = 'a-b',

-- name = 'fi_purify_stone_recipe',
-- type = 'recipe',
-- enabled = 'false',
-- category = 'el_purifier_category',
-- main_product = 'fi_dirty_water',
-- ingredients = {
--     {type="fluid", name="fi_strong_acid", amount=100},
--     {type="fluid", name="water", amount=50},
--     --{type="fluid", name="steam", amount=240, temperature=165},
--     {type="item", name="stone", amount=8}
-- },
-- results = {
--     {type="fluid", name="fi_dirty_water", amount=50},
--     {type="item", name="el_energy_crystal_item", amount=3},
--     {type="item", name="el_materials_pure_iron", amount=3},
--     {type="item", name="el_materials_pure_copper", amount=3},
-- },
-- energy_required = 2,
-- always_show_made_in = true
