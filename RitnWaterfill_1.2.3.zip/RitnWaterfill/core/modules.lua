local modules = {}

modules.events = require("lualib/events")
modules.player = require("lualib/player")

return modules