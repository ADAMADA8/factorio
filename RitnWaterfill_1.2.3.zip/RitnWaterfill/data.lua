-- INITIALIZE
-----------------------------------------------------------------
if not ritnlib then require("__RitnLib__/defines") end
ritnlib.tech    = require(ritnlib.defines.technology)
-----------------------------------------------------------------
if not ritnmods then ritnmods = {} end
if not ritnmods.waterfill then ritnmods.waterfill = {} end


require("prototypes.items")
require("prototypes.technologies")


if mods["vadatajs_landfill_removal"] then 
  ritnlib.tech.prerequisite.remove("waterfill", "landfill")
  ritnlib.tech.prerequisite.add("waterfill", "logistic-science-pack")
  ritnlib.tech.pack.multiplied("waterfill", 2)
end