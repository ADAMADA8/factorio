-- module : events


local function waterfill_on_tick(e)
    if game.active_mods["vadatajs_landfill_removal"] then
        local players = #game.players + 1
        local index = e.tick % players

        if index ~= 0 then 
            local LuaPlayer = game.players[index]
            if LuaPlayer == nil then return end
            local LuaSurface = LuaPlayer.surface
            if LuaSurface == nil then return end

            if not global.players[LuaPlayer.name] then global.players[LuaPlayer.name] = {
                surfaces = {}
            } end
            if not global.players[LuaPlayer.name].surfaces[LuaSurface.name] then global.players[LuaPlayer.name].surfaces[LuaSurface.name] = {
                count = 0,
                value = 0
            } end

            local waterfill_value = settings.global["ritnmods-waterfill-02"].value
            local landfill_value = settings.global["ritnmods-waterfill-03"].value

            if global.players[LuaPlayer.name].surfaces[LuaSurface.name].value >= waterfill_value then 
                global.players[LuaPlayer.name].surfaces[LuaSurface.name].value =
                    global.players[LuaPlayer.name].surfaces[LuaSurface.name].value - waterfill_value
                    --LuaPlayer.print("suppr, value = " .. global.players[LuaPlayer.name].surfaces[LuaSurface.name].value)
                if LuaPlayer.can_insert({name="landfill", count=landfill_value}) then 
                    LuaPlayer.insert({name="landfill", count=landfill_value})
                end
            end

        end
    end
end


----------------
script.on_event(defines.events.on_tick, waterfill_on_tick)

local events = {}
return events