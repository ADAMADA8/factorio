require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")

table.insert(data.raw["technology"]["advanced-material-processing"].effects,{type = "unlock-recipe",recipe = "basic-electric-furnace"})