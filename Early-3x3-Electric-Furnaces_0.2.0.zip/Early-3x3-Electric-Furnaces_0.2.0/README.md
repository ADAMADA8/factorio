# Early-3x3-Electric-Furnaces

A Factorio mod adding large electric furnaces from the start of the game.

Original source comes from https://mods.factorio.com/mod/Electric%20Furnaces
