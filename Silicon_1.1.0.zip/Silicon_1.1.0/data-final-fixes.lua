local stack_size = settings.startup['stack_size'].value
local types = {'item'}

for _,dat in pairs(data.raw) do
	for _,items in pairs(dat) do
		if	
			items.stack_size and items.stack_size > 1 then
			items.stack_size = stack_size
			data.raw.tool["space-science-pack"].stack_size = 1000
		end
	end
end