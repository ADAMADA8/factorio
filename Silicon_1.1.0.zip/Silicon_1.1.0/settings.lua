data:extend(
    {
        {
            type = 'int-setting',
            name = 'stack_size',
            setting_type = 'startup',
            default_value = 500,
            maximum_value = 5000,
            minimum_value = 10,
            order = 'a'
        }
    }
)