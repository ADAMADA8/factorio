-- These are used by sumneko.lua, https://github.com/sumneko/lua-language-server/wiki/EmmyLua-Annotations

---@class MapGenPreset
---@field basic_settings table

