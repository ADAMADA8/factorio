if mods['Krastorio2'] then
	data.raw['equipment-grid']['mini-equipment-grid'].equipment_categories = {"armor", "universal-equipment", "robot-interaction-equipment"}
end