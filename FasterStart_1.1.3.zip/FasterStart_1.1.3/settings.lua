data:extend({
	{
		type = "bool-setting",
		name = "disable-crashsite",
		setting_type = "startup",
		default_value = false,
	},
	{
		type = "bool-setting",
		name = "skip-intro",
		setting_type = "startup",
		default_value = false,
	}
})