# Module Flexibility

Free (or restrict) the use of modules and add in lots of new ones.
