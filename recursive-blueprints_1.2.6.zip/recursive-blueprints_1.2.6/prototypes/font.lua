data:extend{
  {
    type = "font",
    name = "recursive-blueprints-invisible-font",
    from = "default",
    size = 0,
  },
}
