local BeaconInterferenceEntity = {
    NAME_SUFFIX = "-interference"
}

local function tweak_beacons()
    for _, beacon in pairs(data.raw["beacon"]) do
        beacon.supply_area_distance = beacon.supply_area_distance * 3
        beacon.distribution_effectivity = beacon.distribution_effectivity * 2
        local energy_usage = beacon.energy_usage
        local e_units = string.gsub(energy_usage, "%d", "")
        local e_value = string.gsub(energy_usage, "%a", "") / 2
        beacon.energy_usage = e_value .. e_units
        beacon.next_upgrade = nil
    end
end

local function interference_counterpart(beacon)
    local b = table.deepcopy(beacon)
    local beacon_graphics = {
        filename = "__core__/graphics/empty.png",
        priority = "high",
        width = 1,
        height = 1,
        frame_count = 1
    }
    b.name = b.name .. BeaconInterferenceEntity.NAME_SUFFIX
    b.minable = nil
    b.flags = { "placeable-neutral", "player-creation", "placeable-off-grid", "not-blueprintable", "not-deconstructable", "hide-alt-info", "no-automated-item-removal", "no-automated-item-insertion" }
    b.max_health = 10000
    b.healing_per_tick = 10000
    b.collision_mask = { "not-colliding-with-itself" }
    b.order = "z"
    b.base_picture = beacon_graphics
    b.animation = beacon_graphics
    b.animation_shadow = beacon_graphics
    b.radius_visualisation_picture = beacon_graphics
    b.distribution_effectivity = b.distribution_effectivity * -0.95
    return b
end

local function add_interference()
    for _, beacon in pairs(data.raw["beacon"]) do
        if beacon.minable ~= nil then
            data:extend({ interference_counterpart(beacon) })
        end
    end
end

function BeaconInterferenceEntity.setup()
    tweak_beacons()
    add_interference()
end

return BeaconInterferenceEntity
