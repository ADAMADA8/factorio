local BeaconInterferenceEntity = require("prototypes.BeaconInterferenceEntity")

local function updateBeacon(beacon)
    local inventory = beacon.interference.get_module_inventory()
    inventory.clear()
    for _, uid in pairs(beacon.neighbours) do
        if global.beacons[uid] == nil then
            beacon.neighbours[uid] = nil
        else
            local fbeacon = global.beacons[uid].entity
            if fbeacon.energy > 0 and fbeacon.effects ~= nil then
                for item, count in pairs(beacon.entity.get_module_inventory().get_contents()) do
                    inventory.insert({ name = item, count = count })
                    return
                end
            end
        end
    end
end

script.on_event(defines.events.on_tick, function()
    for _, beacon in pairs(global.beacons) do
        beacon.ticks_until_update = beacon.ticks_until_update - 1
        if beacon.ticks_until_update <= 0 then
            beacon.ticks_until_update = 60
            updateBeacon(beacon)
        end
    end
end)

local function on_beacon_removed(beacon)
    local nbeacons = beacon.surface.find_entities_filtered({
        area = beacon.bounding_box,
        name = beacon.name .. BeaconInterferenceEntity.NAME_SUFFIX
    })
    for _, nbeacon in pairs(nbeacons) do
        nbeacon.destroy({ raise_destroy = false })
    end
    global.beacons[beacon.unit_number] = nil
end

local function notify_neighbours(beacon_uid, neighbours)
    for _, uid in pairs(neighbours) do
        global.beacons[uid].neighbours[beacon_uid] = beacon_uid
    end
end

local function find_beacon_neighbours(beacon)
    local result = {}
    local radius = beacon.prototype.supply_area_distance * 2 + 6
    local beacons = beacon.surface.find_entities_filtered({
        type = "beacon",
        area = {
            {beacon.bounding_box.left_top.x - radius, beacon.bounding_box.left_top.y - radius},
            {beacon.bounding_box.right_bottom.x + radius, beacon.bounding_box.right_bottom.y + radius}
        },
        force = beacon.force
    })
    for _, fbeacon in pairs(beacons) do
        if fbeacon ~= beacon and fbeacon.prototype.distribution_effectivity > 0 then
            result[#result + 1] = fbeacon.unit_number
        end
    end
    return result
end

local function on_beacon_created(beacon)
    local nbeacon = beacon.surface.create_entity({
        name = beacon.name .. BeaconInterferenceEntity.NAME_SUFFIX,
        position = beacon.position,
        force = beacon.force,
        raise_built = false
    })
    nbeacon.destructible = false
    local neighbours = find_beacon_neighbours(beacon)
    global.beacons[beacon.unit_number] = {
        entity = beacon,
        interference = nbeacon,
        neighbours = neighbours,
        ticks_until_update = 0
    }
    notify_neighbours(beacon.unit_number, neighbours)
end

local function on_built_entity(event)
    local entity = event.created_entity or event.entity
    if entity ~= nil and entity.valid then
        if entity.type == "beacon" then
            on_beacon_created(entity)
        end
    end
end

local function on_entity_removed(event)
    local entity = event.created_entity or event.entity
    if entity ~= nil and entity.valid then
        if entity.type == "beacon" then
            on_beacon_removed(entity)
        end
    end
end

script.on_init(function()
    global.beacons = {}
    for _, surface in pairs(game.surfaces) do
        local beacons = surface.find_entities_filtered({ type = "beacon" })
        for _, beacon in pairs(beacons) do
            global.beacons[beacon.unit_number] = { neighbours = {} }
        end
        for _, beacon in pairs(beacons) do
            on_beacon_created(beacon)
        end
    end
end)

script.on_event(defines.events.on_built_entity, on_built_entity)
script.on_event(defines.events.on_robot_built_entity, on_built_entity)
script.on_event(defines.events.script_raised_built, on_built_entity)
script.on_event(defines.events.script_raised_revive, on_built_entity)

script.on_event(defines.events.on_entity_died, on_entity_removed)
script.on_event(defines.events.on_pre_player_mined_item, on_entity_removed)
script.on_event(defines.events.on_robot_pre_mined, on_entity_removed)
