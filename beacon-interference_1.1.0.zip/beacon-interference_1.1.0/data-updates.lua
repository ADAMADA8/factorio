require("prototypes.BeaconInterferenceEntity").setup()
