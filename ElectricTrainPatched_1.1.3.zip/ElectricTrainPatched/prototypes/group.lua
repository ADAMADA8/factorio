data:extend(
{
	{
		type = "item-subgroup",
		name = "electric-transport-basic",
		group = "logistics",
		order = "ee",
	},
	{
		type = "item-subgroup",
		name = "electric-transport-loc",
		group = "logistics",
		order = "ef",
	},
	{
		type = "item-subgroup",
		name = "electric-transport-cargo",
		group = "logistics",
		order = "eg",
	},
	{
		type = "item-subgroup",
		name = "electric-transport-fluid",
		group = "logistics",
		order = "eh",
	}
})