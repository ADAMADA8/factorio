data:extend{
	{
	    type = "bool-setting",
	    name = "show-spidertron-legs",
	    setting_type = "startup",
	    default_value = true,
    },

    {
	    type = "bool-setting",
	    name = "stack-spidertron-recipes",
	    setting_type = "startup",
	    default_value = true,
    },
	
	{
	    type = "bool-setting",
	    name = "change-spidertron-remote-recipe",
	    setting_type = "startup",
	    default_value = true,
    },
}