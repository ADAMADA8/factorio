local voyage_spidertron_mk1_equipment_grid = {
    type = "equipment-grid",
    name = "voyage-spidertron-mk1-equipment-grid",
    width = 4,
    height = 4,
    equipment_categories = {"armor"}
}

data:extend{
	voyage_spidertron_mk1_equipment_grid,
}