local scout_spidertron_mk2_equipment_grid = {
    type = "equipment-grid",
    name = "scout-spidertron-mk2-equipment-grid",
    width = 8,
    height = 4,
    equipment_categories = {"armor"}
}

data:extend{
	scout_spidertron_mk2_equipment_grid,
}