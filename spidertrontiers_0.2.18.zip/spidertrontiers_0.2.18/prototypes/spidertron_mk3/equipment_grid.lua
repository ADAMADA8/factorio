local spidertron_mk3_equipment_grid = {
    type = "equipment-grid",
    name = "spidertron-mk3-equipment-grid",
    width = 10,
    height = 20,
    equipment_categories = {"armor"}
}

data:extend{
	spidertron_mk3_equipment_grid,
}