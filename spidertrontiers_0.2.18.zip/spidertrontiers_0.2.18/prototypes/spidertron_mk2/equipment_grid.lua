local spidertron_mk2_equipment_grid = {
    type = "equipment-grid",
    name = "spidertron-mk2-equipment-grid",
    width = 10,
    height = 10,
    equipment_categories = {"armor"}
}

data:extend{
	spidertron_mk2_equipment_grid,
}