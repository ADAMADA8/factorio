local spidertron_mk_1_equipment_grid = {
    type = "equipment-grid",
    name = "spidertron-mk-1-equipment-grid",
    width = 6,
    height = 4,
    equipment_categories = {"armor"}
}

data:extend{
	spidertron_mk_1_equipment_grid,
}