local scout_spidertron_mk1_equipment_grid = {
    type = "equipment-grid",
    name = "scout-spidertron-mk1-equipment-grid",
    width = 4,
    height = 4,
    equipment_categories = {"armor"}
}

data:extend{
	scout_spidertron_mk1_equipment_grid,
}