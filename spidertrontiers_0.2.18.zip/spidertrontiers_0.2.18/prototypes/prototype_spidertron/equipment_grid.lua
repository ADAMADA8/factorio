local prototype_spidertron_equipment_grid = {
    type = "equipment-grid",
    name = "prototype-spidertron-equipment-grid",
    width = 4,
    height = 2,
    equipment_categories = {"armor"}
}

data:extend{
	prototype_spidertron_equipment_grid,
}