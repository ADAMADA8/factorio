local assault_spidertron_mk2_equipment_grid = {
    type = "equipment-grid",
    name = "assault-spidertron-mk2-equipment-grid",
    width = 8,
    height = 4,
    equipment_categories = {"armor"}
}

data:extend{
	assault_spidertron_mk2_equipment_grid,
}