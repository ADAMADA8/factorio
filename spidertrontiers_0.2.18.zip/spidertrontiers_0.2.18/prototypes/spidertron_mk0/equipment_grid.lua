local spidertron_mk0_equipment_grid = {
    type = "equipment-grid",
    name = "spidertron-mk0-equipment-grid",
    width = 10,
    height = 4,
    equipment_categories = {"armor"}
}

data:extend{
	spidertron_mk0_equipment_grid,
}