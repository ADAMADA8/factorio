data:extend(
    {
        {
            type = "sprite",
            name = "DoingThingsByHand",
            filename = "__DoingThingsByHand__/hands.png",
            width = 171,
            height = 128
        }
    }
)
